# E2 — Pipeline ETL

Responsável pela frente: **josegui04monici-arch** · Peso: **35%** · **97 arquivos copiados**.

- [Inventário de cada arquivo](INVENTARIO.md)
- [Obrigações, evidências e pendências](OBRIGACOES.md)
- [Pasta de entrega existente, preservada](../../PI2_Sprint3_Entregas/E2_pipeline/README.md)

## Conteúdo

| Pasta | Arquivos |
|---|---:|
| [codigos/](codigos/) | 49 |
| [dados/](dados/) | 18 |
| [evidencias/](evidencias/) | 7 |
| [relatorios/](relatorios/) | 5 |
| [testes/](testes/) | 18 |

Os arquivos em `codigos` e `testes` são cópias físicas. Os subcaminhos originais foram preservados para permitir incorporá-los ao projeto integrado.

Para executar, reúna E1–E4 usando o montador descrito no [LEIA-ME geral](../LEIA-ME.md). Um setor depende de módulos dos outros setores.

Relatórios anteriores e PDFs históricos são preservados com seu contexto de data. Consulte OBRIGACOES.md para a situação atual.
