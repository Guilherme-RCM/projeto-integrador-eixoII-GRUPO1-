# Arquivos do E2

| Categoria | Arquivo | Por que pertence a este setor |
|---|---|---|
| dados | [data/amostra/receita_amostra_10.csv](dados/data/amostra/receita_amostra_10.csv) | Entradas de amostra e tabelas limpas/prontas produzidas pelo ETL; também usadas pelo E3. |
| dados | [data/limpo/ipca_mensal.csv](dados/data/limpo/ipca_mensal.csv) | Entradas de amostra e tabelas limpas/prontas produzidas pelo ETL; também usadas pelo E3. |
| dados | [data/limpo/quadras_geopalmas.csv](dados/data/limpo/quadras_geopalmas.csv) | Entradas de amostra e tabelas limpas/prontas produzidas pelo ETL; também usadas pelo E3. |
| dados | [data/limpo/quarentena.csv](dados/data/limpo/quarentena.csv) | Entradas de amostra e tabelas limpas/prontas produzidas pelo ETL; também usadas pelo E3. |
| dados | [data/limpo/receita_api_arrecadacao.csv](dados/data/limpo/receita_api_arrecadacao.csv) | Entradas de amostra e tabelas limpas/prontas produzidas pelo ETL; também usadas pelo E3. |
| dados | [data/limpo/receita_nucleogov.csv](dados/data/limpo/receita_nucleogov.csv) | Entradas de amostra e tabelas limpas/prontas produzidas pelo ETL; também usadas pelo E3. |
| dados | [data/limpo/renda_setores_censo2022.csv](dados/data/limpo/renda_setores_censo2022.csv) | Entradas de amostra e tabelas limpas/prontas produzidas pelo ETL; também usadas pelo E3. |
| dados | [data/limpo/setores_ibge.csv](dados/data/limpo/setores_ibge.csv) | Entradas de amostra e tabelas limpas/prontas produzidas pelo ETL; também usadas pelo E3. |
| dados | [data/pronto/base_analitica_creditos.csv.gz](dados/data/pronto/base_analitica_creditos.csv.gz) | Entradas de amostra e tabelas limpas/prontas produzidas pelo ETL; também usadas pelo E3. |
| dados | [data/pronto/cruzamento_setor_quadra.csv](dados/data/pronto/cruzamento_setor_quadra.csv) | Entradas de amostra e tabelas limpas/prontas produzidas pelo ETL; também usadas pelo E3. |
| dados | [data/pronto/inadimplencia_simulada_por_setor.csv](dados/data/pronto/inadimplencia_simulada_por_setor.csv) | Entradas de amostra e tabelas limpas/prontas produzidas pelo ETL; também usadas pelo E3. |
| dados | [data/pronto/indicadores_receita_anual.csv](dados/data/pronto/indicadores_receita_anual.csv) | Entradas de amostra e tabelas limpas/prontas produzidas pelo ETL; também usadas pelo E3. |
| dados | [data/pronto/quadras_socioeconomia.csv](dados/data/pronto/quadras_socioeconomia.csv) | Entradas de amostra e tabelas limpas/prontas produzidas pelo ETL; também usadas pelo E3. |
| dados | [data/pronto/qualidade_dados.json](dados/data/pronto/qualidade_dados.json) | Entradas de amostra e tabelas limpas/prontas produzidas pelo ETL; também usadas pelo E3. |
| dados | [data/pronto/receita_tributaria.csv](dados/data/pronto/receita_tributaria.csv) | Entradas de amostra e tabelas limpas/prontas produzidas pelo ETL; também usadas pelo E3. |
| dados | [data/pronto/sazonalidade_tributos.csv](dados/data/pronto/sazonalidade_tributos.csv) | Entradas de amostra e tabelas limpas/prontas produzidas pelo ETL; também usadas pelo E3. |
| dados | [data/pronto/setores_socioeconomia.csv](dados/data/pronto/setores_socioeconomia.csv) | Entradas de amostra e tabelas limpas/prontas produzidas pelo ETL; também usadas pelo E3. |
| dados | [data/pronto/simulacao_imoveis.csv.gz](dados/data/pronto/simulacao_imoveis.csv.gz) | Entradas de amostra e tabelas limpas/prontas produzidas pelo ETL; também usadas pelo E3. |
| relatorios | [docs/sprint3/ADRs.md](relatorios/docs/sprint3/ADRs.md) | Arquitetura, transformação, dicionário ou relatório do pipeline. |
| relatorios | [docs/sprint3/dicionario_base_analitica.md](relatorios/docs/sprint3/dicionario_base_analitica.md) | Arquitetura, transformação, dicionário ou relatório do pipeline. |
| relatorios | [docs/sprint3/E2_pipeline.md](relatorios/docs/sprint3/E2_pipeline.md) | Arquitetura, transformação, dicionário ou relatório do pipeline. |
| evidencias | [docs/sprint3/evidencias/etl.log](evidencias/docs/sprint3/evidencias/etl.log) | Log da execução do pipeline; também comprova a integração com E1 e E3. |
| evidencias | [docs/sprint3/evidencias/etl_referencia_20261021.log](evidencias/docs/sprint3/evidencias/etl_referencia_20261021.log) | Log da execução do pipeline; também comprova a integração com E1 e E3. |
| relatorios | [docs/sprint3/historico_pdf/RELATORIO_PIPELINE_SPRINT3.pdf](relatorios/docs/sprint3/historico_pdf/RELATORIO_PIPELINE_SPRINT3.pdf) | Arquitetura, transformação, dicionário ou relatório do pipeline. |
| relatorios | [docs/sprint3/limpeza_decisoes.md](relatorios/docs/sprint3/limpeza_decisoes.md) | Arquitetura, transformação, dicionário ou relatório do pipeline. |
| codigos | [etl/__init__.py](codigos/etl/__init__.py) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| codigos | [etl/amostra.py](codigos/etl/amostra.py) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| codigos | [etl/carregar_receita.py](codigos/etl/carregar_receita.py) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| codigos | [etl/config.py](codigos/etl/config.py) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| codigos | [etl/parser.py](codigos/etl/parser.py) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| codigos | [etl/relatorio_validacao.py](codigos/etl/relatorio_validacao.py) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| codigos | [etl/sql_runner.py](codigos/etl/sql_runner.py) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| codigos | [etl_sefin.py](codigos/etl_sefin.py) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| evidencias | [logs/etl_20261021T022405-edcc90.log](evidencias/logs/etl_20261021T022405-edcc90.log) | Log da execução do pipeline; também comprova a integração com E1 e E3. |
| evidencias | [logs/etl_20261021T022446-eb8220.log](evidencias/logs/etl_20261021T022446-eb8220.log) | Log da execução do pipeline; também comprova a integração com E1 e E3. |
| evidencias | [logs/etl_20261021T065517-aa96fd.log](evidencias/logs/etl_20261021T065517-aa96fd.log) | Log da execução do pipeline; também comprova a integração com E1 e E3. |
| evidencias | [logs/etl_20261021T065740-9b9054.log](evidencias/logs/etl_20261021T065740-9b9054.log) | Log da execução do pipeline; também comprova a integração com E1 e E3. |
| evidencias | [logs/etl_20261026T153914-0e36f9.log](evidencias/logs/etl_20261026T153914-0e36f9.log) | Log da execução do pipeline; também comprova a integração com E1 e E3. |
| codigos | [pipeline/__init__.py](codigos/pipeline/__init__.py) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| codigos | [pipeline/atributos/__init__.py](codigos/pipeline/atributos/__init__.py) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| codigos | [pipeline/atributos/base_analitica.py](codigos/pipeline/atributos/base_analitica.py) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| codigos | [pipeline/carga/__init__.py](codigos/pipeline/carga/__init__.py) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| codigos | [pipeline/carga/dados.py](codigos/pipeline/carga/dados.py) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| codigos | [pipeline/carga/mysql.py](codigos/pipeline/carga/mysql.py) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| codigos | [pipeline/carga/registro.py](codigos/pipeline/carga/registro.py) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| codigos | [pipeline/dominio.py](codigos/pipeline/dominio.py) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| codigos | [pipeline/enriquecimento/__init__.py](codigos/pipeline/enriquecimento/__init__.py) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| codigos | [pipeline/enriquecimento/receita.py](codigos/pipeline/enriquecimento/receita.py) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| codigos | [pipeline/enriquecimento/territorio.py](codigos/pipeline/enriquecimento/territorio.py) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| codigos | [pipeline/geo.py](codigos/pipeline/geo.py) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| codigos | [pipeline/limpeza/__init__.py](codigos/pipeline/limpeza/__init__.py) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| codigos | [pipeline/limpeza/censo_ipca.py](codigos/pipeline/limpeza/censo_ipca.py) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| codigos | [pipeline/limpeza/comum.py](codigos/pipeline/limpeza/comum.py) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| codigos | [pipeline/limpeza/receita_api.py](codigos/pipeline/limpeza/receita_api.py) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| codigos | [pipeline/limpeza/receita_nucleogov.py](codigos/pipeline/limpeza/receita_nucleogov.py) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| codigos | [pipeline/limpeza/territorio.py](codigos/pipeline/limpeza/territorio.py) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| codigos | [pipeline/observabilidade.py](codigos/pipeline/observabilidade.py) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| codigos | [pipeline/orquestrador.py](codigos/pipeline/orquestrador.py) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| codigos | [pipeline/qualidade/__init__.py](codigos/pipeline/qualidade/__init__.py) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| codigos | [pipeline/qualidade/validacoes.py](codigos/pipeline/qualidade/validacoes.py) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| codigos | [pipeline/simulacao/__init__.py](codigos/pipeline/simulacao/__init__.py) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| codigos | [pipeline/simulacao/gerador.py](codigos/pipeline/simulacao/gerador.py) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| codigos | [pipeline/simulacao/parametros.py](codigos/pipeline/simulacao/parametros.py) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| codigos | [pipeline/tabelas.py](codigos/pipeline/tabelas.py) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| codigos | [pipeline/transformacao/__init__.py](codigos/pipeline/transformacao/__init__.py) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| codigos | [pipeline/transformacao/fluxo.py](codigos/pipeline/transformacao/fluxo.py) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| codigos | [pipeline/transformacao/gravacao.py](codigos/pipeline/transformacao/gravacao.py) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| codigos | [pipeline/transformacao/leitura.py](codigos/pipeline/transformacao/leitura.py) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| codigos | [sql/dados_referencia.sql](codigos/sql/dados_referencia.sql) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| codigos | [sql/dados_referencia_sprint3.sql](codigos/sql/dados_referencia_sprint3.sql) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| codigos | [sql/schema.sql](codigos/sql/schema.sql) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| codigos | [sql/seed_sintetico.sql](codigos/sql/seed_sintetico.sql) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| codigos | [sql/sprint3.sql](codigos/sql/sprint3.sql) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| codigos | [sql/validacao.sql](codigos/sql/validacao.sql) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| codigos | [src/__init__.py](codigos/src/__init__.py) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| codigos | [src/estruturas/__init__.py](codigos/src/estruturas/__init__.py) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| codigos | [src/estruturas/grafo.py](codigos/src/estruturas/grafo.py) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| codigos | [src/estruturas/heap_prioridade.py](codigos/src/estruturas/heap_prioridade.py) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| codigos | [src/estruturas/indice_hash.py](codigos/src/estruturas/indice_hash.py) | Transformação, atributos, orquestração, carga ou suporte do sistema integrado. |
| testes | [tests/test_amostra.py](testes/tests/test_amostra.py) | Testes de transformação, banco, estruturas ou contratos do pipeline. |
| testes | [tests/test_atributos.py](testes/tests/test_atributos.py) | Testes de transformação, banco, estruturas ou contratos do pipeline. |
| testes | [tests/test_banco.py](testes/tests/test_banco.py) | Testes de transformação, banco, estruturas ou contratos do pipeline. |
| testes | [tests/test_banco_sprint3.py](testes/tests/test_banco_sprint3.py) | Testes de transformação, banco, estruturas ou contratos do pipeline. |
| testes | [tests/test_enriquecimento.py](testes/tests/test_enriquecimento.py) | Testes de transformação, banco, estruturas ou contratos do pipeline. |
| testes | [tests/test_etl_utilitarios.py](testes/tests/test_etl_utilitarios.py) | Testes de transformação, banco, estruturas ou contratos do pipeline. |
| testes | [tests/test_grafo.py](testes/tests/test_grafo.py) | Testes de transformação, banco, estruturas ou contratos do pipeline. |
| testes | [tests/test_heap.py](testes/tests/test_heap.py) | Testes de transformação, banco, estruturas ou contratos do pipeline. |
| testes | [tests/test_indice_hash.py](testes/tests/test_indice_hash.py) | Testes de transformação, banco, estruturas ou contratos do pipeline. |
| testes | [tests/test_integracao_estruturas.py](testes/tests/test_integracao_estruturas.py) | Testes de transformação, banco, estruturas ou contratos do pipeline. |
| testes | [tests/test_limpeza_receita.py](testes/tests/test_limpeza_receita.py) | Testes de transformação, banco, estruturas ou contratos do pipeline. |
| testes | [tests/test_limpeza_territorio.py](testes/tests/test_limpeza_territorio.py) | Testes de transformação, banco, estruturas ou contratos do pipeline. |
| testes | [tests/test_orquestrador.py](testes/tests/test_orquestrador.py) | Testes de transformação, banco, estruturas ou contratos do pipeline. |
| testes | [tests/test_parser.py](testes/tests/test_parser.py) | Testes de transformação, banco, estruturas ou contratos do pipeline. |
| testes | [tests/test_qualidade.py](testes/tests/test_qualidade.py) | Testes de transformação, banco, estruturas ou contratos do pipeline. |
| testes | [tests/test_simulacao.py](testes/tests/test_simulacao.py) | Testes de transformação, banco, estruturas ou contratos do pipeline. |
| testes | [tests/test_tabelas.py](testes/tests/test_tabelas.py) | Testes de transformação, banco, estruturas ou contratos do pipeline. |
| testes | [tests/test_transformacao.py](testes/tests/test_transformacao.py) | Testes de transformação, banco, estruturas ou contratos do pipeline. |
