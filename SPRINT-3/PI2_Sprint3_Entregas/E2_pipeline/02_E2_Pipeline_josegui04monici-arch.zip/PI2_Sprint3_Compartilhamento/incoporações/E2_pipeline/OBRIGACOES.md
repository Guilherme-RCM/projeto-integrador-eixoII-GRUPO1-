# Obrigações do E2 — Pipeline ETL

Responsável pela frente: **josegui04monici-arch**. Peso na rubrica: **35%**.

Situação baseada nos arquivos e resultados já existentes em 26/10/2026. A organização não constitui nova coleta nem nova execução dos gates.

| Obrigação | Situação | Evidência | O que apresentar ou completar |
|---|---|---|---|
| Script único com extract, transform e load | Presente | [etl_sefin.py](codigos/etl_sefin.py) | Usar em conjunto com os módulos E1 e E3, preservando a estrutura original do projeto. |
| Limpeza documentada e bases limpas | Presente | [limpeza_decisoes.md](relatorios/docs/sprint3/limpeza_decisoes.md) | 21 decisões registradas; tabelas em dados/data/limpo. |
| Enriquecimento socioeconômico com IBGE | Presente | [territorio.py](codigos/pipeline/enriquecimento/territorio.py) | O cruzamento territorial e as variáveis socioeconômicas constam do código e das tabelas prontas. |
| Atributos de inadimplência, sazonalidade e faixas de valor | Presente com ressalva | [dicionario_base_analitica.md](relatorios/docs/sprint3/dicionario_base_analitica.md) | Dívida por contribuinte é simulada: manter a indicação SINTETICO/SIMULADO e os limites de uso. |
| Carga no banco da Sprint 2 | Presente | [mysql.py](codigos/pipeline/carga/mysql.py) | Carga histórica e testes MySQL documentados; a regeneração atual foi --offline --sem-banco. |
| Validações de qualidade e logs | Presente | [qualidade_dados.json](dados/data/pronto/qualidade_dados.json) | A rodada registrada passou em 33/33 validações impeditivas; logs disponíveis em evidencias. |

Base: [enunciado da Sprint 3](../E4_reprodutibilidade/relatorios/docs/sprint3/historico_pdf/PI_Sprint3_Entrega27out2026.pdf), páginas 1–2, seções 3, 5 e 6. O painel Power BI é tratado pelo guia do projeto como atividade do Módulo 5.

A atribuição setorial organiza a apresentação e a incorporação. A autoria individual permanece a registrada no diário e no histórico Git.
