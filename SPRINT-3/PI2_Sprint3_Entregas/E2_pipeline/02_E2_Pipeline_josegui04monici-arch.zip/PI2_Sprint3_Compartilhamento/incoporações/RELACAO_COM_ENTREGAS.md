# Relação com a pasta de entregas existente

Todos os arquivos da pasta indicada foram atribuídos a um setor. Eles permanecem intactos no local anterior.

| Arquivo existente | Setor principal | Responsável pela frente |
|---|---|---|
| [comum/DIARIO_DE_BORDO.md](../PI2_Sprint3_Entregas/comum/DIARIO_DE_BORDO.md) | E4 | ALUNO |
| [comum/historico_pdf/PI_Sprint3_Entrega27out2026.pdf](../PI2_Sprint3_Entregas/comum/historico_pdf/PI_Sprint3_Entrega27out2026.pdf) | E4 | ALUNO |
| [comum/historico_pdf/RELATORIO_DETALHADO_SPRINT3.pdf](../PI2_Sprint3_Entregas/comum/historico_pdf/RELATORIO_DETALHADO_SPRINT3.pdf) | E4 | ALUNO |
| [comum/historico_pdf/RELATORIO_PIPELINE_SPRINT3.pdf](../PI2_Sprint3_Entregas/comum/historico_pdf/RELATORIO_PIPELINE_SPRINT3.pdf) | E2 | josegui04monici-arch |
| [comum/RELATORIO_SITUACAO.md](../PI2_Sprint3_Entregas/comum/RELATORIO_SITUACAO.md) | E4 | ALUNO |
| [comum/SPRINT3.md](../PI2_Sprint3_Entregas/comum/SPRINT3.md) | E4 | ALUNO |
| [E1_coleta/ANALISE_CRITICA_COLETA.md](../PI2_Sprint3_Entregas/E1_coleta/ANALISE_CRITICA_COLETA.md) | E1 | samueljaco591 |
| [E1_coleta/E1_coleta.md](../PI2_Sprint3_Entregas/E1_coleta/E1_coleta.md) | E1 | samueljaco591 |
| [E1_coleta/manifesto_resumo.md](../PI2_Sprint3_Entregas/E1_coleta/manifesto_resumo.md) | E1 | samueljaco591 |
| [E1_coleta/README.md](../PI2_Sprint3_Entregas/E1_coleta/README.md) | E1 | samueljaco591 |
| [E2_pipeline/ADRs.md](../PI2_Sprint3_Entregas/E2_pipeline/ADRs.md) | E2 | josegui04monici-arch |
| [E2_pipeline/dicionario_base_analitica.md](../PI2_Sprint3_Entregas/E2_pipeline/dicionario_base_analitica.md) | E2 | josegui04monici-arch |
| [E2_pipeline/E2_pipeline.md](../PI2_Sprint3_Entregas/E2_pipeline/E2_pipeline.md) | E2 | josegui04monici-arch |
| [E2_pipeline/etl.log](../PI2_Sprint3_Entregas/E2_pipeline/etl.log) | E2 | josegui04monici-arch |
| [E2_pipeline/limpeza_decisoes.md](../PI2_Sprint3_Entregas/E2_pipeline/limpeza_decisoes.md) | E2 | josegui04monici-arch |
| [E2_pipeline/README.md](../PI2_Sprint3_Entregas/E2_pipeline/README.md) | E2 | josegui04monici-arch |
| [E3_eda/EDA.md](../PI2_Sprint3_Entregas/E3_eda/EDA.md) | E3 | Guilherme-RCM |
| [E3_eda/figuras/01_evolucao_arrecadacao_real.png](../PI2_Sprint3_Entregas/E3_eda/figuras/01_evolucao_arrecadacao_real.png) | E3 | Guilherme-RCM |
| [E3_eda/figuras/02_composicao_iptu.png](../PI2_Sprint3_Entregas/E3_eda/figuras/02_composicao_iptu.png) | E3 | Guilherme-RCM |
| [E3_eda/figuras/03_sazonalidade.png](../PI2_Sprint3_Entregas/E3_eda/figuras/03_sazonalidade.png) | E3 | Guilherme-RCM |
| [E3_eda/figuras/04_distribuicao_renda_setores.png](../PI2_Sprint3_Entregas/E3_eda/figuras/04_distribuicao_renda_setores.png) | E3 | Guilherme-RCM |
| [E3_eda/figuras/05_relacao_renda_inadimplencia_simulada.png](../PI2_Sprint3_Entregas/E3_eda/figuras/05_relacao_renda_inadimplencia_simulada.png) | E3 | Guilherme-RCM |
| [E3_eda/figuras/06_mapa_renda_setores.png](../PI2_Sprint3_Entregas/E3_eda/figuras/06_mapa_renda_setores.png) | E3 | Guilherme-RCM |
| [E3_eda/figuras/07_mapa_inadimplencia_simulada.png](../PI2_Sprint3_Entregas/E3_eda/figuras/07_mapa_inadimplencia_simulada.png) | E3 | Guilherme-RCM |
| [E3_eda/GALERIA.md](../PI2_Sprint3_Entregas/E3_eda/GALERIA.md) | E3 | Guilherme-RCM |
| [E3_eda/power_bi.md](../PI2_Sprint3_Entregas/E3_eda/power_bi.md) | E3 | Guilherme-RCM |
| [E3_eda/README.md](../PI2_Sprint3_Entregas/E3_eda/README.md) | E3 | Guilherme-RCM |
| [E4_reprodutibilidade/mutacao.md](../PI2_Sprint3_Entregas/E4_reprodutibilidade/mutacao.md) | E4 | ALUNO |
| [E4_reprodutibilidade/qualidade.md](../PI2_Sprint3_Entregas/E4_reprodutibilidade/qualidade.md) | E4 | ALUNO |
| [E4_reprodutibilidade/rastreabilidade_historias.md](../PI2_Sprint3_Entregas/E4_reprodutibilidade/rastreabilidade_historias.md) | E4 | ALUNO |
| [E4_reprodutibilidade/README.md](../PI2_Sprint3_Entregas/E4_reprodutibilidade/README.md) | E4 | ALUNO |
| [E4_reprodutibilidade/README_do_projeto.md](../PI2_Sprint3_Entregas/E4_reprodutibilidade/README_do_projeto.md) | E4 | ALUNO |
| [manifesto_entregas.json](../PI2_Sprint3_Entregas/manifesto_entregas.json) | E4 | ALUNO |
| [README.md](../PI2_Sprint3_Entregas/README.md) | E4 | ALUNO |
| [referencias/referencias.json](../PI2_Sprint3_Entregas/referencias/referencias.json) | E3 | Guilherme-RCM |
| [referencias/REFERENCIAS.md](../PI2_Sprint3_Entregas/referencias/REFERENCIAS.md) | E3 | Guilherme-RCM |
| [referencias/referencias_verificadas.json](../PI2_Sprint3_Entregas/referencias/referencias_verificadas.json) | E3 | Guilherme-RCM |
