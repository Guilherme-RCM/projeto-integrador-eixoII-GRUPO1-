# Incoporações por entrega — E1, E2, E3 e E4

Esta é uma pasta nova, separada de `PI2_Sprint3_Entregas`. Cada arquivo do projeto foi copiado e atribuído a **um setor principal**, conforme sua função. Os códigos e relatórios estão fisicamente nas pastas correspondentes; os arquivos anteriores permanecem intactos.

| Setor | Responsável pela frente | O que fica aqui |
|---|---|---|
| [E1 — Coleta](E1_coleta/README.md) | samueljaco591 | Coletor, HTTP, paginação, robots.txt, testes da coleta, bruto datado e manifesto |
| [E2 — Pipeline](E2_pipeline/README.md) | josegui04monici-arch | Script principal, limpeza, enriquecimento, atributos, simulação, carga, SQL, bases limpas/prontas e logs |
| [E3 — EDA](E3_eda/README.md) | Guilherme-RCM | Geradores da EDA, gráficos, mapas, relatório, galeria, bibliografia e guia do Power BI |
| [E4 — Reprodutibilidade](E4_reprodutibilidade/README.md) | ALUNO | Configuração, dependências, testes de aceitação, gates, documentação de execução, diário e organização da entrega |

## Localizar cada arquivo

- [Índice completo: arquivo → setor](INDICE_ARQUIVOS.md).
- [Índice em CSV](INDICE_ARQUIVOS.csv), com origem, destino, responsável pela frente e justificativa.
- [Relação dos arquivos da pasta de entregas anterior com cada setor](RELACAO_COM_ENTREGAS.md).
- [Manifesto com atribuições e hashes](MANIFESTO_ARQUIVOS.json).

Cada pasta E1–E4 contém `README.md`, `INVENTARIO.md` e `OBRIGACOES.md`. As categorias `codigos`, `testes`, `relatorios`, `dados`, `figuras`, `referencias` e `evidencias` aparecem conforme o conteúdo do setor.

## Critério de atribuição

O setor indica quem apresenta, mantém e incorpora aquele arquivo à entrega. A atribuição por setor **não comprova autoria individual**: os autores dos trabalhos continuam sendo aqueles registrados no diário e nos commits.

Os arquivos compartilhados têm um único local principal. As tabelas prontas ficam no E2, embora a EDA do E3 as utilize. A bibliografia fica no E3 e serve às quatro frentes. Configuração, aceitação global e documentação transversal ficam no E4. Os protótipos antigos estão marcados em `E4_reprodutibilidade/apoio_fora_do_escopo`; não são novas obrigações da Sprint 3.

## O que ainda precisa ser incorporado

- **E1:** confirmar o registro do Portal de Dados Abertos, citado no objetivo do enunciado, ou a justificativa para sua exclusão.
- **E2:** apresentar a carga e as validações existentes, mantendo explícito que a dívida por contribuinte é simulada. Não foi criada uma nova base real.
- **E3:** produzir o `.pbix` e a captura do filtro cruzado previstos no guia do Módulo 5. O mapa de inadimplência existente deve permanecer marcado como SIMULADO.
- **E4:** recolher os registros próprios dos colegas, confirmar a composição formal da equipe e concluir integração/publicação e envio do link após a revisão da equipe.

As listas detalhadas estão em [E1](E1_coleta/OBRIGACOES.md), [E2](E2_pipeline/OBRIGACOES.md), [E3](E3_eda/OBRIGACOES.md) e [E4](E4_reprodutibilidade/OBRIGACOES.md). As obrigações foram conferidas no enunciado, páginas 1–2. O enunciado define quatro entregáveis e menciona cinco integrantes; a divisão fornecida traz quatro usuários, por isso não foi criado um E5 nem inventado outro integrante.

## Executar os códigos reunidos

As pastas setoriais são partes do mesmo projeto Python. Para reunir as cópias em uma nova pasta executável, abra o terminal nesta pasta e execute:

```powershell
python E4_reprodutibilidade/codigos/organizacao/montar_projeto.py
cd projeto_integrado
python -m pip install -r requirements-dev.txt
python etl_sefin.py --offline --sem-banco
```

O montador cria `projeto_integrado` somente dentro de `incoporações` e recusa sobrescrever um destino existente. Ele reúne as cópias locais, inclusive se você editar os códigos dos setores, sem copiar suas alterações para o projeto ou as entregas anteriores. Dependências e `.env` seguem o README do projeto; credenciais não foram copiadas.

## Conferência desta organização

A organização verifica atribuição única por caminho de origem, hashes dos códigos/dados, sintaxe Python, links dos índices e preservação das pastas anteriores. Nos relatórios Markdown, apenas os links locais foram ajustados para os novos destinos. PDFs e arquivos de código foram copiados sem alteração.

O resultado está em [VERIFICACAO.json](E4_reprodutibilidade/evidencias/organizacao/VERIFICACAO.json). A rodada anterior de 14/14 gates e 780 testes foi preservada como evidência; os gates não foram reexecutados nesta organização de arquivos.

Os índices desta pasta e os scripts de organização são materiais administrativos do E4. O gerador `organizar_incorporacoes.py` foi usado uma vez e recusa uma segunda execução sobre este pacote, para proteger eventuais edições locais.
