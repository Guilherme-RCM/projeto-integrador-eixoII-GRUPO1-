# E3 — Análise exploratória

Responsável pela frente: **Guilherme-RCM** · Peso: **25%** · **27 arquivos copiados**.

- [Inventário de cada arquivo](INVENTARIO.md)
- [Obrigações, evidências e pendências](OBRIGACOES.md)
- [Pasta de entrega existente, preservada](../../PI2_Sprint3_Entregas/E3_eda/README.md)

## Conteúdo

| Pasta | Arquivos |
|---|---:|
| [codigos/](codigos/) | 12 |
| [figuras/](figuras/) | 7 |
| [referencias/](referencias/) | 2 |
| [relatorios/](relatorios/) | 4 |
| [testes/](testes/) | 2 |

Os arquivos em `codigos` e `testes` são cópias físicas. Os subcaminhos originais foram preservados para permitir incorporá-los ao projeto integrado.

Para executar, reúna E1–E4 usando o montador descrito no [LEIA-ME geral](../LEIA-ME.md). Um setor depende de módulos dos outros setores.

Relatórios anteriores e PDFs históricos são preservados com seu contexto de data. Consulte OBRIGACOES.md para a situação atual.
