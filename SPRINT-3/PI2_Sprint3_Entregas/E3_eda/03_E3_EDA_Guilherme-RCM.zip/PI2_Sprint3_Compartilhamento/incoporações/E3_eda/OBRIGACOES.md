# Obrigações do E3 — Análise exploratória

Responsável pela frente: **Guilherme-RCM**. Peso na rubrica: **25%**.

Situação baseada nos arquivos e resultados já existentes em 26/10/2026. A organização não constitui nova coleta nem nova execução dos gates.

| Obrigação | Situação | Evidência | O que apresentar ou completar |
|---|---|---|---|
| EDA com estatísticas descritivas | Presente | [EDA.md](relatorios/docs/sprint3/EDA.md) | Relatório gerado a partir das tabelas do E2; códigos do gerador e testes incluídos. |
| Evolução, composição, distribuição e relação | Presente | [GALERIA.md](relatorios/docs/sprint3/GALERIA.md) | Sete PNGs com frases de leitura, fontes e coerência com os dados. |
| Mapa de inadimplência por setor urbano | Presente com ressalva | [07_mapa_inadimplencia_simulada.png](figuras/docs/sprint3/figuras/07_mapa_inadimplencia_simulada.png) | O mapa existe, mas a inadimplência é SIMULADA. Não apresentá-la como dívida real observada. |
| Citação de sazonalidade e bibliografia conferida | Presente | [REFERENCIAS.md](relatorios/docs/sprint3/REFERENCIAS.md) | Measurement of Seasonal Fluctuations, DOI 10.2307/1928756; 75/75 DOIs no cache já conferido. |
| Painel v1 .pbix e captura do filtro cruzado (apoio do Módulo 5) | Pendente | [power_bi.md](relatorios/docs/sprint3/power_bi.md) | Guia e medidas já existem. Produzir powerbi/painel_sefin_v1.pbix e docs/sprint3/figuras/powerbi_filtro_cruzado.png; não estão incluídos como concluídos. |

Base: [enunciado da Sprint 3](../E4_reprodutibilidade/relatorios/docs/sprint3/historico_pdf/PI_Sprint3_Entrega27out2026.pdf), páginas 1–2, seções 3, 5 e 6. O painel Power BI é tratado pelo guia do projeto como atividade do Módulo 5.

A atribuição setorial organiza a apresentação e a incorporação. A autoria individual permanece a registrada no diário e no histórico Git.
