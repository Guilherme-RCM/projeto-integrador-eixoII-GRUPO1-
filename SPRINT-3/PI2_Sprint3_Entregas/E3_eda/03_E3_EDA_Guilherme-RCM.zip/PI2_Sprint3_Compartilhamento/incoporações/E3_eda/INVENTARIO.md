# Arquivos do E3

| Categoria | Arquivo | Por que pertence a este setor |
|---|---|---|
| relatorios | [docs/sprint3/EDA.md](relatorios/docs/sprint3/EDA.md) | Análise, apresentação dos resultados e bibliografia. |
| figuras | [docs/sprint3/figuras/01_evolucao_arrecadacao_real.png](figuras/docs/sprint3/figuras/01_evolucao_arrecadacao_real.png) | Visualizações entregues pela análise exploratória. |
| figuras | [docs/sprint3/figuras/02_composicao_iptu.png](figuras/docs/sprint3/figuras/02_composicao_iptu.png) | Visualizações entregues pela análise exploratória. |
| figuras | [docs/sprint3/figuras/03_sazonalidade.png](figuras/docs/sprint3/figuras/03_sazonalidade.png) | Visualizações entregues pela análise exploratória. |
| figuras | [docs/sprint3/figuras/04_distribuicao_renda_setores.png](figuras/docs/sprint3/figuras/04_distribuicao_renda_setores.png) | Visualizações entregues pela análise exploratória. |
| figuras | [docs/sprint3/figuras/05_relacao_renda_inadimplencia_simulada.png](figuras/docs/sprint3/figuras/05_relacao_renda_inadimplencia_simulada.png) | Visualizações entregues pela análise exploratória. |
| figuras | [docs/sprint3/figuras/06_mapa_renda_setores.png](figuras/docs/sprint3/figuras/06_mapa_renda_setores.png) | Visualizações entregues pela análise exploratória. |
| figuras | [docs/sprint3/figuras/07_mapa_inadimplencia_simulada.png](figuras/docs/sprint3/figuras/07_mapa_inadimplencia_simulada.png) | Visualizações entregues pela análise exploratória. |
| relatorios | [docs/sprint3/GALERIA.md](relatorios/docs/sprint3/GALERIA.md) | Análise, apresentação dos resultados e bibliografia. |
| relatorios | [docs/sprint3/power_bi.md](relatorios/docs/sprint3/power_bi.md) | Análise, apresentação dos resultados e bibliografia. |
| referencias | [docs/sprint3/referencias.json](referencias/docs/sprint3/referencias.json) | Catálogo e cache da bibliografia comum às quatro entregas. |
| relatorios | [docs/sprint3/REFERENCIAS.md](relatorios/docs/sprint3/REFERENCIAS.md) | Análise, apresentação dos resultados e bibliografia. |
| referencias | [docs/sprint3/referencias_verificadas.json](referencias/docs/sprint3/referencias_verificadas.json) | Catálogo e cache da bibliografia comum às quatro entregas. |
| codigos | [pipeline/eda/__init__.py](codigos/pipeline/eda/__init__.py) | Geração da EDA, gráficos ou conferência/formatador da bibliografia. |
| codigos | [pipeline/eda/dados.py](codigos/pipeline/eda/dados.py) | Geração da EDA, gráficos ou conferência/formatador da bibliografia. |
| codigos | [pipeline/eda/estatisticas.py](codigos/pipeline/eda/estatisticas.py) | Geração da EDA, gráficos ou conferência/formatador da bibliografia. |
| codigos | [pipeline/eda/estilo.py](codigos/pipeline/eda/estilo.py) | Geração da EDA, gráficos ou conferência/formatador da bibliografia. |
| codigos | [pipeline/eda/formato.py](codigos/pipeline/eda/formato.py) | Geração da EDA, gráficos ou conferência/formatador da bibliografia. |
| codigos | [pipeline/eda/graficos.py](codigos/pipeline/eda/graficos.py) | Geração da EDA, gráficos ou conferência/formatador da bibliografia. |
| codigos | [pipeline/eda/mapas.py](codigos/pipeline/eda/mapas.py) | Geração da EDA, gráficos ou conferência/formatador da bibliografia. |
| codigos | [pipeline/eda/relatorio.py](codigos/pipeline/eda/relatorio.py) | Geração da EDA, gráficos ou conferência/formatador da bibliografia. |
| codigos | [pipeline/eda/secoes_receita.py](codigos/pipeline/eda/secoes_receita.py) | Geração da EDA, gráficos ou conferência/formatador da bibliografia. |
| codigos | [pipeline/eda/secoes_territorio.py](codigos/pipeline/eda/secoes_territorio.py) | Geração da EDA, gráficos ou conferência/formatador da bibliografia. |
| codigos | [pipeline/referencias.py](codigos/pipeline/referencias.py) | Geração da EDA, gráficos ou conferência/formatador da bibliografia. |
| codigos | [scripts/verificar_referencias.py](codigos/scripts/verificar_referencias.py) | Geração da EDA, gráficos ou conferência/formatador da bibliografia. |
| testes | [tests/test_eda.py](testes/tests/test_eda.py) | Testes da EDA e das referências. |
| testes | [tests/test_referencias.py](testes/tests/test_referencias.py) | Testes da EDA e das referências. |
